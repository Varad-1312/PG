/*Write a program to accept a text file from user and display the contents of a file in
reverse order and change its case. */

import java.io.*;
import java.util.*;
class file
{
    public static void main(String[] args) throws Exception
    {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter file name:");
		String fname=sc.next();
        FileReader f1=new FileReader(fname);
        BufferedReader b1=new BufferedReader(f1);
        String s;
        StringBuffer s1=new StringBuffer();
        while((s=b1.readLine())!=null)
        {
            s=s.toUpperCase();
            s1.append(s+"\n");
        }
        s1.reverse();
        System.out.println(s1);
    }
}
