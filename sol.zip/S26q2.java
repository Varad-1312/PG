//Slip 26_2
import java.io.*;
import java.util.*;
class Donor
{
	int dno,age;
	String dname,date,phno,add,bg;

	void accept()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter dno:");
		dno=sc.nextInt();
		System.out.println("Enter age:");
		age=sc.nextInt();
		System.out.println("Enter dname:");
		dname=sc.next();	
		System.out.println("Enter date:");
		date=sc.next();
		System.out.println("Enter phno:");
		phno=sc.next();
		System.out.println("Enter add:");
		add=sc.next();
		System.out.println("Enter blood grp:");
		bg=sc.next();
	
	}
	public static void main(String ar[]) throws Exception
	{
		int i;
		Donor ob[]=new Donor[1];
		for(i=0;i<1;i++)
		{
			ob[i]=new Donor();
			ob[i].accept();
		}
	    FileWriter f1=new FileWriter("Donor.txt");
	    BufferedWriter bw=new BufferedWriter(f1);
	
	for(i=0;i<1;i++)
	{
		bw.write(ob[i].dno+"\t");
		bw.write(ob[i].age+"\t");
		bw.write(ob[i].dname+"\t");
		bw.write(ob[i].date+"\t");
		bw.write(ob[i].phno+"\t");
		bw.write(ob[i].add+"\t");
		bw.write(ob[i].bg+"\t");
		bw.write("\n");
	}
	bw.close();
	FileReader f2=new FileReader("Donor.txt");
	BufferedReader br=new BufferedReader(f2);
	String s1="";
	while((s1=br.readLine())!=null)
	{
		String s2[]=s1.split("\t");
		if(s2[5].equals("pune") && s2[6].equals("A"))
		{	
			System.out.println(s1);
		}
	}
	}
}