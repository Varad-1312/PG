import java.util.*;
class DispVov extends Thread
{
	DispVov() 
	{
		start();
	}
	public void run()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String=");
		String name=sc.next();
		try 
		{
			for(int i=0;i<name.length();i++)
			{
				
				if(name.charAt(i)=='a' || name.charAt(i)=='e' || name.charAt(i)=='i' || name.charAt(i)=='o' || name.charAt(i)=='u')
				{
					sleep(3000);
					System.out.println(name.charAt(i));
				}
			}
		} catch (Exception e) 
		{
			System.out.println(e);
		}
	}
}
public class Slip23_1
{

	public static void main(String[] args) 
	{
		DispVov d=new DispVov();
	}

}
