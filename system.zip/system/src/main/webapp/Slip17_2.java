import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class NumDemo extends JFrame implements ActionListener,Runnable
{
    JTextField t1;
    JButton b1;
    JPanel p1;
    Thread th;
	NumDemo() 
	{
		setVisible(true);
		setSize(500,500);
		p1=new JPanel();
		b1=new JButton("Start");
		t1=new JTextField(20);
		p1.add(t1);
		p1.add(b1);
		add(p1);
		b1.addActionListener(this);
	}
	public void run()
	{
		try 
		{
			for(int i=1;i<=100;i++)
			{
				th.sleep(1000);
				t1.setText(""+i);
			}
		} catch (Exception e) 
		{
			JOptionPane.showMessageDialog(this,e);
		}
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			if(ae.getSource()==b1)
			{
				th=new Thread(this);
				th.start();

			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}
}
public class Slip17_2
{

	public static void main(String[] args) 
	{
		new NumDemo();
	}

}
