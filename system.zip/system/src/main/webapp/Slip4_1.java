import java.awt.*;
import javax.swing.*;
class demo1 extends Frame implements Runnable
{
	Label l1;
	Thread th;
	demo1()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(new FlowLayout());
		l1=new Label("Hello");
		add(l1);
		th=new Thread(this);
		th.start();
	}
		
	public void run()
	{
	  try 
	 {
	   while(true)
	   {
		   
		   
		   th.sleep(100);
		   l1.setVisible(false);
		   th.sleep(100);
		   l1.setVisible(true);
	   }  
	  } catch (Exception e) 
	  {
		  JOptionPane.showMessageDialog(this,"ERROR="+e);
	  }	
	}
}
public class Slip4_1 
{

	public static void main(String[] args)
	{
		demo1 d=new demo1();
	}

}
