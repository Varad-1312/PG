import java.util.Random;

class t1 extends Thread
{
	t1()
	{
		start();
	}
	
	public void run()
	{
		Random r1=new Random();
		try 
		{	
			while(true)
			{
				sleep(1000);
				int n=r1.nextInt(100);
				if(n%2==0)
				{
					t2 t2=new t2(n);
				}
				else
				{
					t3 t3=new t3(n);
				}
			}
		} catch (Exception e) 
		{
			System.out.println(e);
		}
	}
	
}
class t2 extends Thread
{
	int n;
	t2(int n)
	{
		this.n=n;
		start();
	}
	public void run()
	{
		System.out.println("Square of "+n+" is "+n*n);
	}
}
class t3 extends Thread
{
	int n;
	t3(int n)
	{
		this.n=n;
		start();
	}
	public void run()
	{
		System.out.println("Cube of "+n+" is "+n*n*n);
	}
}
public class Slip7_1
{

	public static void main(String[] args) 
	{
		t1 t1=new t1();
	}

}
