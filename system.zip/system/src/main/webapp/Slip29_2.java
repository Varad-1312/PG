import java.util.*;
public class Slip29_2
{

	public static void main(String[] args) 
	{
		LinkedList<Integer> l=new LinkedList<Integer>();
		l.add(10);l.add(20);l.add(30);l.add(40);
		
		//add element at first 
		l.addFirst(50);
		System.out.println("After Add Element in First Position="+l);
		
		//delete last position element
		
		l.removeLast();
		System.out.println("After Removing Last Elememnt From List="+l);
		
	    System.out.println("Size of LinkedList="+l.size());
	}

}
