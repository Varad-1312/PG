import java.util.*;
public class Slip21_1 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		LinkedList<String>l1=new LinkedList<String>();
		
		System.out.println("Enter Limit=");
		int n=sc.nextInt();
		
		System.out.println("Enter "+n+" Subjects=");
		for(int i=0;i<n;i++)
		{
			l1.add(sc.next());
		}
		
		Iterator<String> i= l1.iterator();
		
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

	}

}