import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/Slips18_2")
public class Slip18_2 extends HttpServlet 
{


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		
		String sno=request.getParameter("t1");
		String sname=request.getParameter("t2");
		String cls=request.getParameter("t3");
		int mark=Integer.parseInt(request.getParameter("t3"));
		
		int tot=(mark/500)*100;
		
		out.println("<html><body><h2>Student Details</h2>");
		out.println("<h4>Seat Number:"+sno+"</h4>");
		out.println("<h4>Student Name:"+sname+"</h4>");
		out.println("<h4>Student Class:"+cls+"</h4>");
		out.println("<h4>Total Marks:"+tot+"</h4>");
		
		if(tot>=90)
		{
			out.println("<h4>Grade: Distinction");
		}
		else if(tot>=80)
		{
			out.println("<h4>Grade: A");
		}
		else if(tot>=60)
		{
			out.println("<h4>Grade: B");
		}
		else if(tot>=50)
		{
			out.println("<h4>Grade: c");
		}
		else
		{
			out.println("<h4>Grade: F");
		}
	}

}
