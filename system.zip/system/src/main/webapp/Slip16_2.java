import java.sql.*;
import java.util.*;
public class Slip16_2 
{

	public static void main(String[] args)
	{
		try
		{
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost/college","postgres","1234");
			PreparedStatement pst=con.prepareStatement("insert into teacher values(?,?,?)");
			Scanner sc=new Scanner(System.in);
			for(int i=1;i<=5;i++)
			{
				System.out.println("Enter Teacher No=");
				int no=sc.nextInt();
				System.out.println("Enter Teacher Name=");
				String nm=sc.next();
				System.out.println("Enter Teacher Subject=");
				String sub=sc.next();
				pst.setInt(1, no);
				pst.setString(2,nm);
				pst.setString(3, sub);
				int k=pst.executeUpdate();
				if(k>=1)
				{
					System.out.println("Inserted Successfully....!");
				}
				else
				{
					System.out.println("Error in insertion");
				}				
			}
			
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from teacher where subject='java'");
			System.out.println("Tno \t Tname \t Subject");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
