class testThread1 extends Thread
{
	testThread1()
	{
		start();
	}
	public void run()
	{
		System.out.println("Thread Name="+getName());
		System.out.println("Thread Priority="+getPriority());
	}
}
public class Slip18_1
{

	public static void main(String[] args) 
	{
		testThread1 th=new testThread1();
		th.setPriority(Thread.MAX_PRIORITY);
	}

}
