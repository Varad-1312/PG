class testThread extends Thread
{
	testThread()
	{
		start();
	}
	public void run()
	{
		System.out.println("Thread Name="+getName());
		System.out.println("Thread Priority="+getPriority());
	}
}
public class Slip15_1
{

	public static void main(String[] args) 
	{
		testThread th=new testThread();
		th.setPriority(Thread.MAX_PRIORITY);
	}

}
