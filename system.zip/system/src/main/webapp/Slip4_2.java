import java.util.*;
public class Slip4_2 
{

	public static void main(String[] args) 
	{
		HashMap<String, String> h=new HashMap<String,String>();
		Scanner sc=new Scanner(System.in);
		//add city and std code in hashmap
		h.put("Shrirampur", "123");
		h.put("Pune", "124");
		h.put("Mumbai", "125");
		
		int ch;
		do 
		{
			
			System.out.println("1.Add a new city and its code \n2.Remove a city and its code \n3.search a city name and display its code");
			System.out.println("Enter your choice=");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1: System.out.println("Enter city name=");
			        String nm=sc.next();
			        System.out.println("Enter STD code=");
			        String c=sc.next();
			        if(h.containsKey(nm))
			        {
			        	h.put(nm, c);
			        	System.out.println("Successfully added");
			        }
			        else
			        {
			        	System.out.println("Already exist");
			        }
			        break;
			     
			case 2: System.out.println("Enter city name to search=");
			        String n=sc.next();
			        h.remove(n);
			        System.out.println("City remove successfully");
			        break;
			       
			case 3: System.out.println("Enter city name to search=");
	                String n1=sc.next();
	                if(h.containsKey(n1))
			        {
			        	System.out.println("STD CODE="+h.get(n1));
			        }
	                
			}
		} while (ch<4);
		
	}

}