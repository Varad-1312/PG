
class threadDemo1 extends Thread
{
	
	public void run()
	 {
		 System.out.println("Currently Running Thread"+getName());
	 }
}
class threadDemo2 extends Thread
{
	
	public void run()
	 {
		 System.out.println("Currently Running Thread"+getName());
	 }
}
class threadDemo3 extends Thread
{
	
	public void run()
	 {
		 System.out.println("Currently Running Thread"+getName());
	 }
}
public class Slip28_2 extends Thread 
{
	 
	public static void main(String[] args) 
	{
		threadDemo1 th1=new threadDemo1();
		threadDemo2 th2=new threadDemo2();
		threadDemo3 th3=new threadDemo3();
		
		th1.start();
		th2.start();
		th3.start();
	}

}
