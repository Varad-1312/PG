import java.util.*;
public class Slip6_1 
{

	public static void main(String[] args) 
	{
		TreeSet<Integer> t=new TreeSet<Integer>();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Limit=");
		int n=sc.nextInt();
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Value=");
			t.add(sc.nextInt());
		}
		
		System.out.println("Sorted Order="+t); // sorting
		
		System.out.println("Enter Number to search=");
		int num=sc.nextInt();
		
		if(t.contains(num))
		{
			System.out.println("Number found");
		}
		else 
		{
			System.out.println("Number not found");
		}
	}

}
