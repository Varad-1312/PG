import java.util.*;
public class Slip23_2
{

	public static void main(String[] args) 
	{
		LinkedList<String> l1=new LinkedList<String>();
		
		for(String name : args)
		{
			l1.add(name);
		}
		
		Iterator<String> i1= l1.iterator();
		System.out.println("Names using Iterator=");
		while(i1.hasNext())
		{
			System.out.print(i1.next()+" ");
		}
		
		System.out.println("Names using ListIterator=");
		ListIterator<String> lt= l1.listIterator();
		while(lt.hasNext())
		{
			System.out.print(lt.next()+" ");
		}
	}
}