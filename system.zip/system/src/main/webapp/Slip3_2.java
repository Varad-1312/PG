import java.util.*;
public class Slip3_2 
{

	public static void main(String[] args) 
	{
		LinkedList l1=new LinkedList();
		l1.add("Apple");
		l1.add("Banana");
        System.out.println(l1);
        
        l1.addLast("cherry"); //add element at the last position of list
        System.out.println(l1);
        
        l1.removeFirst(); // Delete First Element of list
        System.out.println(l1);
        
        Collections.reverse(l1); // reverse LinkedList
        System.out.println("Revers List="+l1);
	}

}
