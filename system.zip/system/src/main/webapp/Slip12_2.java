import javax.swing.*;
import java.util.*;
import java.sql.*;
class DispTable extends JFrame
{
	JTable jt;
	JScrollPane jsp;
	JPanel p;
	DispTable() 
	{
		try 
		{
			setVisible(true);
			setSize(600,600);
			Vector<Vector> records=new Vector<Vector>();
			Vector<String> head=new Vector<String>();
			head.add("Project_id");head.add("Project_name");head.add("Project_des");head.add("Project_status");
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost/college","adesh","1234");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from project");
			while(rs.next())
			{
				Vector<String> r1=new Vector<String>();
				r1.add(rs.getString(1));
				r1.add(rs.getString(2));
				r1.add(rs.getString(3));
				r1.add(rs.getString(4));
				records.add(r1);
			}
			jt=new JTable(records,head);
			jsp=new JScrollPane(jt);
			add(jsp);
			
		} catch (Exception e) 
		{
			JOptionPane.showMessageDialog(this, e);
		}
		
	}
}


public class Slip12_2
{

	public static void main(String[] args) 
	{
		new DispTable();
	}

}
