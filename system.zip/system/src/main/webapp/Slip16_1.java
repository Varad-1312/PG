import java.text.Collator;
import java.util.*;
public class Slip16_1
{

	public static void main(String[] args) 
	{
		TreeSet<String> t=new TreeSet<String>();
		t.add("Red");
		t.add("Blakc");
		t.add("Orange");
		System.out.println(t);
	}

}
