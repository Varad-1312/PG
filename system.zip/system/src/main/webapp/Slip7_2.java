import java.sql.*;

public class Slip7_2 
{

	public static void main(String[] args)
	{
		try
		{
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost/college","postgres","1234");
			Statement st=con.createStatement();
			st.executeUpdate("create table product(pid int,pname text,price int)");
			st.executeUpdate("insert into product values(101,'pen',10)");
			st.executeUpdate("insert into product values(102,'notebook',30)");
			st.executeUpdate("insert into product values(103,'book',100)");
			st.executeUpdate("insert into product values(104,'scale',15)");
			int k=st.executeUpdate("insert into product values(105,'color',120)");
			if(k>=1)
				System.out.println("Table created and Values inserted ");
			
			ResultSet rs=st.executeQuery("select * from product");
			while(rs.next())
			{
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			}
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
