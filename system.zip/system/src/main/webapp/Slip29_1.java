import java.sql.*;
public class Slip29_1
{

	public static void main(String[] args) 
	{
		try 
		{
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection("jdbc:postgresql://localhost/college","postgres","1234");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from donar");
			ResultSetMetaData rsd=rs.getMetaData();
			
			int count = rsd.getColumnCount();
            System.out.println("Column Information for DONAR Table:");
            for (int i = 1; i <= count; i++)
            {
                System.out.println("Column Name: " + rsd.getColumnName(i));
                System.out.println("Data Type: " + rsd.getColumnTypeName(i));
                System.out.println("Column Size: " + rsd.getColumnDisplaySize(i));
            }
			
		} catch (Exception e)
		{
			System.out.println(e);
		}
	}

}
