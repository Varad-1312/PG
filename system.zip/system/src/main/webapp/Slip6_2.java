import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;

class traffic extends JFrame implements Runnable
{
	JButton red,green,yellow;
	Thread th;
	traffic()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		th=new Thread(this);
		
		this.setBackground(Color.white);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		red=new JButton();
		yellow=new JButton();
		green=new JButton();
		
		red.setBackground(Color.WHITE);
		red.setBounds(100, 100, 40, 40);

		yellow.setBackground(Color.WHITE);
		yellow.setBounds(100, 160, 40, 40);
		
		green.setBackground(Color.WHITE);
		green.setBounds(100, 220, 40, 40);
		
		add(red);
		add(yellow);
		add(green);
		th.start();
	}
	public void run()
	{
		while(true)
		{
			try
			{			
				red.setBackground(Color.red);
				th.sleep(500);
				red.setBackground(Color.WHITE);				
				yellow.setBackground(Color.YELLOW);
				th.sleep(500);
				yellow.setBackground(Color.WHITE);
				green.setBackground(Color.GREEN);
				th.sleep(500);
				green.setBackground(Color.WHITE);
				
				
			}catch(Exception e)
			{
				JOptionPane.showMessageDialog(this, e);
			}
			
		}
	}
	
}
public class Slip6_2 {

	public static void main(String[] args)
	{
		new traffic();
	}

}
