import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/slip2")
public class Slip19_2 extends HttpServlet 
{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		PrintWriter out=res.getWriter();
		String user=req.getParameter("t1");
		String pass=req.getParameter("t2");
		try 
		{
			Class.forName("org.postgresql.Driver");
			Connection con=DriverManager.getConnection("jdbc:postgresql://localhost/college","postgres","1234");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from login where username='"+user+"' AND password='"+pass+"'");
			if(rs.next())
			{
				out.println("<h1>Login Successfully");
			}
			else 
			{
				out.println("<h1>Invalid Username and Password");
			}
			
		} catch (Exception e)
		{
			
		}
		
		
		
	}
}
