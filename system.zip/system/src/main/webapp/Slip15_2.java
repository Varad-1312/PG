import java.io.IOException;
import java.io.PrintWriter;
import java.security.Provider.Service;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Slip15_2 extends HttpServlet
{

   @Override
  protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
   {
	   Cookie ck=new Cookie("count","1");
	   res.addCookie(ck);
	   String s1=ck.getValue();
	   int n=Integer.parseInt(s1);
	   PrintWriter out=res.getWriter();
	   if(n==1)
	   {
		   out.println("<h1>Welcome");
		   n++;
		   s1=""+n;
		   ck.setValue(s1);
	   }
	   else
	   {
		   out.println("<h1>Visited Time="+n);
		   n++;
		   s1=""+n;
		   ck.setValue(s1);
	   }
   }

}
