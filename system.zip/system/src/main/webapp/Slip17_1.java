import java.util.*;
public class Slip17_1
{
	public static void main(String args[])
	{
		TreeSet<Integer> t1 = new TreeSet<Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Limit=");
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Number=");
			t1.add(sc.nextInt());
		}
		
		System.out.println("Integers in Sorted Order="+t1);
	}
}
