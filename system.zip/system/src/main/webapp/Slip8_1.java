
class thread1 extends Thread
{
	int n;
	String text;
	thread1(int n,String text)
	{
		this.n=n;
		this.text=text;
		start();
	}
	public void run()
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(text);
		}
	}
	
}
class thread2 extends Thread
{
	int n;
	String text;
	thread2(int n,String text)
	{
		this.n=n;
		this.text=text;
		start();
	}
	public void run()
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(text);
		}
	}
	
}
class thread3 extends Thread
{
	int n;
	String text;
	thread3(int n,String text)
	{
		this.n=n;
		this.text=text;
		start();
	}
	public void run()
	{
		for(int i=0;i<n;i++)
		{
			System.out.println(text);
		}
	}
	
}
public class Slip8_1 
{

	public static void main(String[] args) 
	{
		thread1 t1=new thread1(10,"COVID19");
		thread2 t2=new thread2(20,"LOCKDOWN2020");
		thread3 t3=new thread3(30,"VACCINATED2021");
	}

}
