import java.util.*;
public class Slip19_1 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		LinkedList<Integer> l1= new LinkedList<Integer>();
		
		System.out.println("Enter Limit=");
		int n=sc.nextInt();
		
		System.out.println("Enters "+n+" Integers=");
		for(int i=1;i<=n;i++)
		{
			l1.add(sc.nextInt());
		}
		
		System.out.println("Negitive Integers=");
		for (int i: l1) 
		{
			if(i<0)
			{
				System.out.println(i+" ");
			}
		}
		
	}

}
